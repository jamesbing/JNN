package org.neuroph.core.events;

/**
 *
 * @author Zoran Sevarac
 */
public enum LearningEventType {
    EPOCH_ENDED, LEARNING_STOPPED;
}
